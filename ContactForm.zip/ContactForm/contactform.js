import React from 'react';
import emailjs from 'emailjs-com';



import ".contactform.html";
import './contactform.css';

export default function contactform() {

  function sendEmail(e) {
    e.preventDefault();

    emailjs.sendForm('service_alxnsch', 'template_kg6f2r8', e.target, 'user_lUqspGpfYLY0xCQ5DWIXb')

      .then((result) => {
          console.log(result.text);
      }, (error) => {
          console.log(error.text);
      });
  }


  return(
    <form className="contact-form" onSubmit={sendEmail}>
    
         
          <label>Firstname</label>
    
          <input type="text" name="First_name" />
    
           <label>Lastname</label>
    
          <input type="text" name="Last_name" />
    
    
          <label>EmailAddress</label>
    
          <input type="email" name="EmailAddress" />
    
       <label>Address</label>
    
      <input type="text" name="Address" />
    
    
          <label>Message</label>
    
    
          <textarea name="message" />
    
          <input type="submit" value="Send" />
        </form>
    )
    };

    export default contactform;  