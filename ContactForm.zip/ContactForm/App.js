import './App.css';
import ContactForm from './ContactForm';

const App = () => {
  return (
    <div className="App">                 
        <ContactForm />           
    </div>
  );
}

export default App;